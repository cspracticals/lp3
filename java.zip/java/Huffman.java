import java.util.*;

class Node implements Comparable<Node> {
    char ch;
    int freq;
    Node left, right;

    Node(char ch, int freq) {
        this.ch = ch;
        this.freq = freq;
    }

    Node(int freq, Node left, Node right) {
        this.ch = '\0';
        this.freq = freq;
        this.left = left;
        this.right = right;
    }

    public int compareTo(Node other) {
        return this.freq - other.freq;
    }
}

public class Huffman {
    static void printCodes(Node root, String code) {
        if (root == null) return;
        if (root.left == null && root.right == null && root.ch != '\0')
            System.out.println(root.ch + " : " + code);
        printCodes(root.left, code + "0");
        printCodes(root.right, code + "1");
    }

    public static void main(String[] args) {
        char[] chars = {'a', 'b', 'c', 'd', 'e', 'f'};
        int[] freq = {5, 9, 12, 13, 16, 45};

        PriorityQueue<Node> heap = new PriorityQueue<>();
        for (int i = 0; i < chars.length; i++)
            heap.add(new Node(chars[i], freq[i]));

        while (heap.size() > 1) {
            Node left = heap.poll();
            Node right = heap.poll();
            Node newNode = new Node(left.freq + right.freq, left, right);
            heap.add(newNode);
        }

        Node root = heap.peek();
        System.out.println("Character : Huffman Code");
        printCodes(root, "");
    }
}
